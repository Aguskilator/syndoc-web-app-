# istanbul-lib-source-maps

[![Build Status](https://img.shields.io/github/actions/workflow/status/istanbuljs/istanbuljs/ci.yml?label=CI&logo=GitHub)](https://github.com/istanbuljs/istanbuljs/actions/workflows/ci.yml)

Source map support for istanbuljs.

## Debugging

`istanbul-lib-source-maps` uses the [debug](https://www.npmjs.com/package/debug) module. Run your application with the environment variable `DEBUG=istanbuljs`, to receive debug
output.
