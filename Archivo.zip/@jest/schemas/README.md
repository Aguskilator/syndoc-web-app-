# `@jest/schemas`

Experimental and currently incomplete module for JSON schemas for [Jest's](https://jestjs.io/) configuration.
