# @jest/core

Jest is currently working on providing a programmatic API. This is under development, and usage of this package directly is currently not supported.
