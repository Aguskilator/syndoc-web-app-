# @jest/pattern

`@jest/pattern` is a helper library for the jest library that implements the logic for parsing and matching patterns.
