// Original file: null

import type { Long } from '@grpc/proto-loader';

export interface Int64Value {
  'value'?: (number | string | Long);
}

export interface Int64Value__Output {
  'value': (string);
}
