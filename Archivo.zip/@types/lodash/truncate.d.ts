import { truncate } from "./index";
export = truncate;
