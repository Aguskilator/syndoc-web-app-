import { reject } from "./index";
export = reject;
