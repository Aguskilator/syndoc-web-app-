import { rearg } from "./index";
export = rearg;
