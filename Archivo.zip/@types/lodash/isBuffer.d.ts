import { isBuffer } from "./index";
export = isBuffer;
